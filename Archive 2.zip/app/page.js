import Image from "next/image";
import network from "../public/network-icon.svg";
import server from "../public/server-icon.svg";
import serverWhite from "../public/server-icon-white.svg";
import wifi from "../public/wifi-icon.svg";
import cables from "../public/cables-icon.svg";
import voipWhite from "../public/voip-icon-white.svg";
import networkWhite from "../public/network-icon-white.svg";
import cctvWhite from "../public/cctv-icon-white.svg";
import mainimage from "../public/images/homepage-image.jpg";
import InfoBoxes from "@/components/InfoBoxes";

export default function Home() {
  const infoBoxData = [
    {
      svgIcon: networkWhite,
      heading: "Network",
      info: "From wireless access point installations to retrofitting, and everything in between, we do it all.",
      btnText: "Get Connected",
      location: "network",
    },
    {
      svgIcon: cctvWhite,
      heading: "CCTV",
      info: "Keeping tabs on your livelihood is important. We ensure that you have the tools at your disposal to ensure it.",
      btnText: "Keep an Eye",
      location: "cctv",
    },
    {
      svgIcon: serverWhite,
      heading: "Servers",
      info: "The difference between the 21st century and the stone age is the server infrastructure being in use. We guide you that future.",
      btnText: "Power Up",
      location: "servers",
    },
    {
      svgIcon: voipWhite,
      heading: "VoIp",
      info: "A dropped call can make or break an important business deal. We work to make sure that you don't have to worry about problems such as these.",
      btnText: "Hear it All",
      location: "voip",
    },
  ];

  return (
    <div className="cursor-default mt-24">
      <div className=" relative flex flex-col lg:flex-row px-6 lg:mb-12 lg:px-32 ">
        <Image
          className=" w-96  my-4 lg:my-16 self-center justify-self-center duration-1000 animate-in slide-in-from-left-96 ease-in"
          src={mainimage}
          alt="home page image"
        />

        <div className=" mb-12 lg:mb-0 mx-6 lg:mx-0 lg:ml-16 lg:w-[45] flex-col md:flex py-6  content-center justify-around ">
          <div>
            <h1 className=" mb-8  text-5xl xl:text-6xl font-bold text-[#EB8401] xl:leading-tight duration-1000 animate-in slide-in-from-top-96 ease-in">
              I.T. support at every important hour of the day.
            </h1>
          </div>

          <div className=" duration-1000 animate-in slide-in-from-right-96 ease-in">
            <h1 className="mb-6 lg:text-2xl font-bold ">
              Looking for the right people to talk to you?
            </h1>
            <h1 className="mb-16 lg:text-1xl font-semibold text-[#B0B0B0]">
              We understand technology can be troublesome at the most
              inconvenient of times, which is why we always make sure our
              clients have a helping hand to grab on to.
            </h1>
          </div>
          <div>
            <div className=" flex justify-around  ">
              <Image
                className="ease-in-out hover:-translate-y-3 hover:scale-150 duration-300"
                height={35}
                src={network}
                alt="Network Icon"
              />
              <Image
                className="ease-in-out hover:-translate-y-3 hover:scale-150 duration-300"
                height={35}
                src={server}
                alt="Network Icon"
              />
              <Image
                className="ease-in-out hover:-translate-y-3 hover:scale-150 duration-300"
                height={35}
                src={wifi}
                alt="Network Icon"
              />
              <Image
                className="ease-in-out hover:-translate-y-3 hover:scale-150 duration-300"
                height={35}
                src={cables}
                alt="Network Icon"
              />
            </div>
          </div>
        </div>
      </div>
      <div className=" md:px-32 py-16 bg-gradient-to-r from-[#F9B301] to-[#EB8401]">
        <div className="flex flex-col items-center">
          <h1 className=" text-white text-4xl font-bold transition ">
            Our core services
          </h1>
          <h1 className=" text-black md:text-2xl font-semibold mt-5">
            Looking for the right people to talk to you?
          </h1>

          <div className="flex flex-wrap justify-around px-6 md:px-32 w-[90dvw] ">
            {infoBoxData.map((info) => (
              <InfoBoxes
                key={info.heading}
                svgIcon={info.svgIcon}
                info={info.info}
                heading={info.heading}
                btnText={info.btnText}
                location={info.location}
              />
            ))}
          </div>
        </div>
      </div>
      <div className="lg:flex px-6 md:px-32 py-16 items-center w-[100%] justify-between">
        <div className=" mb-6 text-4xl lg:w-[30dvw] lg:text-6xl font-semibold leading-tight text-transparent bg-clip-text bg-gradient-to-br from-[#EB8401] to-[#F9B301]">
          Clients opinions with our Service
        </div>
        <div className=" lg:w-[50%] h-70">
          <h1 className="text-2xl font-bold mb-6">Madré</h1>
          <h1 className=" text-lg font-semibold">
            " You guys are amazing. Thank you so much for all your effort and
            willingness. Will most definitely recommend you. "
          </h1>
        </div>
      </div>
    </div>
  );
}
